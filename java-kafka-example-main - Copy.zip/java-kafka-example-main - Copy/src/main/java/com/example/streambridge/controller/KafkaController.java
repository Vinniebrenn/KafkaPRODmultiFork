package com.example.streambridge.controller;

import com.example.streambridge.service.impl.KafkaPublishService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/kafka")  // <-- version prefix added here
@Slf4j
public class KafkaController {

    private final KafkaPublishService publishService;

    public KafkaController(KafkaPublishService publishService) {
        this.publishService = publishService;
    }

    @Operation(summary = "Publish message to Kafka topic")
    @PostMapping("/publish")
    public ResponseEntity<String> publish(
            @Parameter(description = "Target Kafka topic") @RequestParam String topic,
            @Parameter(description = "Key for partitioning") @RequestParam String key,
            @Parameter(description = "Message content") @RequestParam String message) {

        log.info("Received publish request - topic: {}, key: {}", topic, key);
        return publishService.publish(topic, key, message);
    }
}

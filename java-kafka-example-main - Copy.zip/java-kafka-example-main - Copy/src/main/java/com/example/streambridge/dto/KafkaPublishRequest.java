package com.example.streambridge.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class KafkaPublishRequest {

    @NotBlank
    @Schema(description = "Kafka topic", example = "topic-a")
    private String topic;

    @NotBlank
    private String key;

    @NotBlank
    private String message;

}
package com.example.streambridge.service.impl;

import com.example.streambridge.config.KafkaProperties;
import com.example.streambridge.util.KafkaProducerManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.util.concurrent.ExecutionException;

@Service
@Slf4j
@EnableRetry  // Enable retry support here or on a config class
public class KafkaPublishService {

    private final KafkaProducerManager producerManager;
    private final KafkaProperties kafkaProperties;

    public KafkaPublishService(KafkaProducerManager producerManager, KafkaProperties kafkaProperties) {
        this.producerManager = producerManager;
        this.kafkaProperties = kafkaProperties;
    }

    @Retryable(
        value = {Exception.class},  // retry on all exceptions; customize if needed
        maxAttempts = 3,
        backoff = @Backoff(delay = 2000))
    public ResponseEntity<String> publish(String topic, String key, String message) {
        log.info("Attempting to publish message to topic: '{}', key: '{}'", topic, key);

        KafkaProperties.TopicSecurity topicSecurity = kafkaProperties.getTopics().stream()
                .filter(t -> t.getName().equals(topic))
                .findFirst()
                .orElseThrow(() -> {
                    String error = "No security config found for topic: " + topic;
                    log.error(error);
                    return new IllegalArgumentException(error);
                });

        KafkaProperties.Truststore truststore = kafkaProperties.getTruststore();

        try {
            producerManager.sendMessage(
                    topic,
                    key,
                    message,
                    topicSecurity.getJaasConfig(),
                    kafkaProperties.getBootstrapServers(),
                    truststore.getLocation(),
                    truststore.getPassword()
            ).get();

            log.info("Successfully published message to topic: '{}'", topic);
            return ResponseEntity.ok("Message published to topic: " + topic);

        } catch (ExecutionException e) {
            Throwable rootCause = e.getCause();
            log.error("Kafka publish failed due to execution error: {}", rootCause.getMessage(), rootCause);
            throw new RuntimeException(rootCause);  // throw to trigger retry

        } catch (Exception e) {
            log.error("Unexpected error while publishing to topic '{}': {}", topic, e.getMessage(), e);
            throw new RuntimeException(e);  // throw to trigger retry
        }
    }
}

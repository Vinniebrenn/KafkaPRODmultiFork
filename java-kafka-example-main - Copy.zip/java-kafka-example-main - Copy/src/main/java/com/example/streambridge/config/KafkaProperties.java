package com.example.streambridge.config;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "kafka")
public class KafkaProperties {

    private String bootstrapServers;
    private Truststore truststore;
    private List<TopicSecurity> topics;

    public static class Truststore {
        private String location;
        private String password;
        // getters and setters
		public String getLocation() {
			return location;
		}
		public void setLocation(String location) {
			this.location = location;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
    }

    public String getBootstrapServers() {
		return bootstrapServers;
	}

	public void setBootstrapServers(String bootstrapServers) {
		this.bootstrapServers = bootstrapServers;
	}

	public Truststore getTruststore() {
		return truststore;
	}

	public void setTruststore(Truststore truststore) {
		this.truststore = truststore;
	}

	public List<TopicSecurity> getTopics() {
		return topics;
	}

	public void setTopics(List<TopicSecurity> topics) {
		this.topics = topics;
	}

	public static class TopicSecurity {
        private String name;
        private String jaasConfig;
        // getters and setters
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getJaasConfig() {
			return jaasConfig;
		}
		public void setJaasConfig(String jaasConfig) {
			this.jaasConfig = jaasConfig;
		}
    }

    // getters and setters
}

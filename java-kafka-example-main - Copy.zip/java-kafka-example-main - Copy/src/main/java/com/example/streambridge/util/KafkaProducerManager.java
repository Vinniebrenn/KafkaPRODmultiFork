package com.example.streambridge.util;

import java.util.Base64;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class KafkaProducerManager {

	private final Map<String, KafkaProducer<String, String>> producers = new ConcurrentHashMap<>();

	private String createProducerKey(String jaasConfig, String truststoreLocation) {
		String jaasHash = DigestUtils.sha256Hex(jaasConfig);
		String truststoreHash = DigestUtils.sha256Hex(truststoreLocation);
		return jaasHash + "-" + truststoreHash;
	}

	public KafkaProducer<String, String> getOrCreateProducer(String jaasConfig, String bootstrapServers,
			String truststoreLocation, String truststorePassword) {
		String producerKey = createProducerKey(jaasConfig, truststoreLocation);
		return producers.computeIfAbsent(producerKey, cfg -> {
			log.info("Creating new KafkaProducer with config key: {}", producerKey);
			Properties props = new Properties();

			props.put("bootstrap.servers", bootstrapServers);
			props.put("security.protocol", "SASL_SSL"); // Kerberos + SSL
			props.put("sasl.mechanism", "GSSAPI");
			props.put("sasl.jaas.config", jaasConfig);

			// SSL Truststore settings
			props.put("ssl.truststore.location", truststoreLocation);
			props.put("ssl.truststore.password", truststorePassword);
			props.put("ssl.endpoint.identification.algorithm", ""); // disable hostname check if needed

			props.put("key.serializer", StringSerializer.class.getName());
			props.put("value.serializer", StringSerializer.class.getName());

			log.debug("Kafka producer properties: {}", props);

			return new KafkaProducer<>(props);
		});
	}

	public CompletableFuture<RecordMetadata> sendMessage(String topic, String key, String message, String jaasConfig,
			String bootstrapServers, String truststoreLocation, String truststorePassword) {
		KafkaProducer<String, String> producer = getOrCreateProducer(jaasConfig, bootstrapServers, truststoreLocation,
				truststorePassword);
		CompletableFuture<RecordMetadata> future = new CompletableFuture<>();

	    // Encrypt the message before sending
	   // String encryptedMessage = encryptAES(message, secretKey); // secret key

	    log.info("Sending encrypted message to topic '{}' with key '{}'", topic, key);
		producer.send(new ProducerRecord<>(topic, key, message), (metadata, exception) -> {
			if (exception != null) {
				log.error("Failed to send message to topic '{}', key '{}': {}", topic, key, exception.getMessage(),
						exception);
				future.completeExceptionally(exception);
			} else {
				log.info("Message sent successfully to topic '{}', partition {}, offset {}", metadata.topic(),
						metadata.partition(), metadata.offset());
				future.complete(metadata);
			}
		});

		return future;
	}
	
	// AES encryption helper
	private String encryptAES(String plainText, String secret) throws Exception {
	    byte[] keyBytes = secret.getBytes("UTF-8");
	    SecretKeySpec secretKey = new SecretKeySpec(keyBytes, "AES");

	    Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	    cipher.init(Cipher.ENCRYPT_MODE, secretKey);

	    byte[] encryptedBytes = cipher.doFinal(plainText.getBytes("UTF-8"));
	    return Base64.getEncoder().encodeToString(encryptedBytes);
	}
}
